package com.bodhixu.school.school.bean;

import lombok.Data;

/**
 * @author 丰哥
 * 2022/01/07
 *
 * 前后端交互的数据结构
 */
@Data
public class ResultInfo {

    private Integer code; // 状态码
    private String msg; // 状态信息
    private Object data; // 数据

    public void setOk() {
        this.code = 200;
        this.msg = "ok";
    }

    public void setError() {
        this.code = 500;
        this.msg = "error";
    }
}
