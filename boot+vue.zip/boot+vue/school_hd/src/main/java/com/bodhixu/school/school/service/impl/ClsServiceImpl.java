package com.bodhixu.school.school.service.impl;

import com.bodhixu.school.school.bean.Cls;
import com.bodhixu.school.school.mapper.ClsMapper;
import com.bodhixu.school.school.service.ClsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 丰哥
 * 2022/01/07
 */
@Service
public class ClsServiceImpl implements ClsService {

    @Autowired
    private ClsMapper clsMapper;

    @Override
    public List<Cls> qureyAll() throws Exception {
        return clsMapper.qureyAll();
    }

    @Override
    public List<Cls> queryByName(String name) throws Exception {
        return clsMapper.queryByName(name);
    }

    @Override
    public Cls qureyById(Integer id)  throws Exception{
        return clsMapper.qureyById(id);
    }

    @Override
    public void deleteByID(Integer id) throws Exception {
        clsMapper.deleteByID(id);
    }

    @Override
    public Cls insert(Cls cls) throws Exception {
        System.out.println("插入前:" + cls);
        clsMapper.insert(cls);
        System.out.println("插入后:" + cls);
        return cls;
    }

    @Override
    public void update(Cls cls) throws Exception {
        clsMapper.update(cls);
    }

}
