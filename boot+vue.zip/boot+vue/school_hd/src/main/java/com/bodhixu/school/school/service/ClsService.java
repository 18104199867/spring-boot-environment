package com.bodhixu.school.school.service;

import com.bodhixu.school.school.bean.Cls;

import java.util.List;

/**
 * @author 丰哥
 * 2022/01/07
 */
public interface ClsService {

    List<Cls> qureyAll() throws Exception;

    List<Cls> queryByName(String name) throws Exception;

    Cls qureyById(Integer id)  throws Exception;

    void deleteByID(Integer id) throws Exception;

    Cls insert(Cls cls)  throws Exception;

    void update(Cls cls) throws Exception;
}
