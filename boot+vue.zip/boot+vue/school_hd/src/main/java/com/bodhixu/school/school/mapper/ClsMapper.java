package com.bodhixu.school.school.mapper;

import com.bodhixu.school.school.bean.Cls;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * @author 丰哥
 * 2022/01/07
 */
@Mapper
public interface ClsMapper {

    @Select("select * from cls")
    List<Cls> qureyAll() throws Exception;

    @Select("select * from cls where name like '%${value}%'")
    List<Cls> queryByName(String name) throws Exception;

    @Select("select * from cls where id = #{id} limit 1")
    Cls qureyById(Integer id) throws Exception;

    @Delete("delete from cls where id = #{id}")
    void deleteByID(Integer id) throws Exception;

    @Options(useGeneratedKeys = true, keyColumn = "id", keyProperty = "id")
    @Insert("insert into cls values (default, #{name})")
    void insert(Cls cls) throws Exception;

    @Update("update cls set name = #{name} where id = #{id}")
    void update(Cls cls) throws Exception;
}
