package com.bodhixu.school.school.controller;

import com.bodhixu.school.school.bean.Cls;
import com.bodhixu.school.school.bean.ResultInfo;
import com.bodhixu.school.school.service.ClsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author 丰哥
 * 2022/01/07
 */
//@Controller
//@ResponseBody
@RestController
@RequestMapping("/admin/school/")
public class ClsController {

    @Autowired
    private ClsService clsService;

    // ① restful的uri路径，要求中文复数
    // ② @RequestMapping 接受任意的请求方式

    // 限定请求方式，方法1
    //@RequestMapping(value = "/clses", method = RequestMethod.GET)
    // 限定请求方式，方法2
    //@GetMapping("/clses")

    // 将javabean对象转成json，响应给前端
    //@ResponseBody
    //public List<Cls> clses() {
    //    try {
    //        List<Cls> clsList = clsService.qureyAll();
    //        return clsList;
    //    } catch (Exception e) {
    //        e.printStackTrace();
    //    }
    //    return null;
    //}

    //@GetMapping("/clses")
    //@ResponseBody
    //public Map<String, Object> stus() {
    //    Map<String, Object> map = new HashMap<>();
    //
    //    try {
    //        List<Cls> clsList = clsService.qureyAll();
    //
    //        map.put("code", 200);
    //        map.put("msg", "ok");
    //        map.put("data", clsList);
    //
    //    } catch (Exception e) {
    //        e.printStackTrace();
    //
    //        map.put("code", 500);
    //        map.put("msg", "error");
    //        map.put("data", null);
    //    }
    //    return map;
    //}

    //@GetMapping("/clses")
    //@ResponseBody
    //public ResultInfo stus() {
    //    ResultInfo ri = new ResultInfo();
    //    try {
    //        List<Cls> clsList = clsService.qureyAll();
    //        ri.setOk();
    //        ri.setData(clsList);
    //    } catch (Exception e) {
    //        e.printStackTrace();
    //        ri.setError();
    //    }
    //    return ri;
    //}

    // 查询全部班级
    //@CrossOrigin
    @GetMapping("/clses")
    public ResultInfo queryClses() {
        ResultInfo ri = new ResultInfo();
        try {
            List<Cls> clsList = clsService.qureyAll();
            ri.setOk();
            ri.setData(clsList);
        } catch (Exception e) {
            e.printStackTrace();
            ri.setError();
        }
        return ri;
    }

    // 根据班级名称模糊查询
    // @RequestParam 请求参数和形参绑定
    @GetMapping("/clsesbyname")
    public ResultInfo queryByName(@RequestParam("name") String name) {
        System.out.println(name);
        ResultInfo ri = new ResultInfo();
        try {
            List<Cls> clses = clsService.queryByName(name);
            ri.setOk();
            ri.setData(clses);
        } catch (Exception e) {
            e.printStackTrace();
            ri.setError();
        }
        return ri;
    }

    // 根据编号查询制定班级
    // @PathVariable：将路径变量和形参绑定
    @GetMapping("/clses/{cid}")
    public ResultInfo queryById(@PathVariable("cid") Integer id) {
        ResultInfo ri = new ResultInfo();
        try {
            Cls cls = clsService.qureyById(id);
            ri.setOk();
            ri.setData(cls);
        } catch (Exception e) {
            e.printStackTrace();
            ri.setError();
        }
        return ri;
    }

    // 接受token请求
    // @RequestHeader 请求头的参数和形参绑定
    @GetMapping("/clsesGetToken")
    public ResultInfo clsesGetToken(@RequestHeader("usertoken") String usertoken) {
        System.out.println(usertoken);
        return new ResultInfo();
    }

    // 根据id删除指定班级
    @DeleteMapping("/clses/{id}")
    public ResultInfo deleteByID(@PathVariable("id") Integer id) {
        ResultInfo ri = new ResultInfo();

        try {
            clsService.deleteByID(id);
            ri.setOk();
        } catch (Exception e) {
            e.printStackTrace();
            ri.setError();
        }

        return ri;
    }

    // 添加班级
    // 请求发送的数据格式是key-value键值对，后端可以直接映射成bean
    // 请求发送的数据格式是json，后端@RequestBody把json映射bean
    @PostMapping("/clses")
    public ResultInfo addCls(@RequestBody Cls cls) {
        System.out.println(cls);
        ResultInfo ri = new ResultInfo();

        try {
            Cls newCls = clsService.insert(cls);
            ri.setOk();
            ri.setData(newCls);
        } catch (Exception e) {
            e.printStackTrace();
            ri.setError();
        }
        return ri;
    }

    //@PatchMapping
    //public ResultInfo updateNameById(String name, Integer name);

    @PutMapping("/clses")
    public ResultInfo update(Cls cls) {
        ResultInfo ri = new ResultInfo();

        try {
            clsService.update(cls);
            ri.setOk();
            ri.setData(cls);
        } catch (Exception e) {
            e.printStackTrace();
            ri.setError();
        }
        return ri;
    }

}
