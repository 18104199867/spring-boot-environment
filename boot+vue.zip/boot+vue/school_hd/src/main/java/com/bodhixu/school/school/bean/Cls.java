package com.bodhixu.school.school.bean;

import lombok.Data;

/**
 * @author 丰哥
 * 2022/01/07
 */
@Data
public class Cls {

    private Integer id;
    private String name;

}
