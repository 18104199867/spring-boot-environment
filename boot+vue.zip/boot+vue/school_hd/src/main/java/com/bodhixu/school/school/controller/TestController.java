package com.bodhixu.school.school.controller;

import com.bodhixu.school.school.bean.ResultInfo;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test/")
public class TestController {

    @GetMapping("/test01/{id}")
    public void test01(@PathVariable Integer id){
        System.out.println(id);
        ResultInfo resultInfo = new ResultInfo();
        resultInfo.setCode(200);
        resultInfo.setMsg("成功返回");
    }
}
