package com.bodhixu.school.school.mapper;

import com.bodhixu.school.school.bean.Cls;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

/**
 * @author 丰哥
 * 2022/01/07
 */
@SpringBootTest
@Slf4j
public class ClsMapperTest {

    @Autowired
    private ClsMapper clsMapper;

    @Test
    void testQueryAll() throws Exception {
        List<Cls> clsList = clsMapper.qureyAll();
        clsList.forEach(cls -> System.out.println(cls));
    }

}
