package com.bodhixu.school.school.mapper;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;

@SpringBootTest
public class SQLtest {
    
    @Autowired
    ClsMapper clsMapper;

    @Test
    void sqltest(){
//        List<Cls> clses = clsMapper.qureyAll();
        ArrayList<Object> lists = new ArrayList<>();
        lists.add("aaa");
        lists.add("bbb");
        for (Object list : lists) {
            System.out.println((String) list);
        }
    }
}
